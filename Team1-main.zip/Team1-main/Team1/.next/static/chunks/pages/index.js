__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_755291._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_06228f._.js",
  "static/chunks/[root of the server]__2e95cd._.js",
  "static/chunks/node_modules_@fontsource_poppins_index_3b86dc.css",
  "static/chunks/pages_index_5771e1._.js",
  "static/chunks/pages_index_8d85e1._.js"
])
