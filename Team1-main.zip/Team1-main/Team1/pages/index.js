
import Body from './Body';
export default function Home() {
  return (
<div >
<title>OJT Monitoring</title> {/* Change this */}
<meta name="description" content="Your website description" /> {/* Update description too */}
  <Body />
</div>
  );
}
